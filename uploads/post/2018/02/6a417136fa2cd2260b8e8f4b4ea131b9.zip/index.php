<!DOCTYPE HTML>
<html lang="ko">
<head>
<title>한알의 기적 혈케어365</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="no">
<meta name="robots" content="index,follow">

<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Expires" content="-1">

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<link type="text/css" rel="stylesheet" href="<?=$AD_DIR?>/css/style.css">

<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->

<script type="text/javascript">
$(function () {
	$('#scrollToBottom').bind("click", function () {
		$('html, body').animate({ scrollTop: $(document).height() }, 0);
		return false;
	});
});
</script>
</head>
<body>
<div>

	<div class="container">
		<section><img src="<?=$AD_DIR?>/images/1.jpg"></section>
		<section><img src="<?=$AD_DIR?>/images/2.jpg"></section>
		<section><img src="<?=$AD_DIR?>/images/3.jpg"></section>
		<section><img src="<?=$AD_DIR?>/images/4.jpg"></section>
		<section><img src="<?=$AD_DIR?>/images/5.jpg"></section>

		<section id="inDB">
			<h3>전문상담사가 친절히 상담해 드립니다.</h3>
			<table>
				<colgroup>
					<col width="">
					<col width="">
				</colgroup>
				<tbody>
					<tr>
						<th>성 함</th>
						<td><input type="text" class="form-class"  id="M_NAME"></td>
					</tr>
					<tr>
						<th>나 이</th>
						<td><input type="number" class="form-class" id="M_AGE" style="width:auto; float:left;"> <label style="position:relative;float:left; top:10px; left:10px;">세</label></td>
					</tr>
					<tr>
						<th>연락처</th>
						<td><input type="tel" class="form-class"  id="M_HP"></td>
					</tr>
					<tr>
						<th>남기고<br>싶은말</th>
						<td>
							<textarea class="form-class" rows="5" id="M_QUESTION"></textarea>
						</td>
					</tr>
					<tr>
						<td colspan="2" class="t-center">
							<div class="checkbox">
								<input type="checkbox" name="" id="agree" checked> <label for="agree">개인정보 수집 및 이용동의</label>
							</div>
						</td>
					</tr>
					<tr>
						<td colspan="2" class="t-center" style="padding:0;">
							<a onclick="APPLY_SUBMIT();"><img src="<?=$AD_DIR?>/images/btn.jpg"></a>
						</td>
					</tr>
				</tbody>
			</table>
		</section>

		<section><img src="<?=$AD_DIR?>/images/7.jpg"></section>
		<section><img src="<?=$AD_DIR?>/images/8.jpg"></section>
		<section><img src="<?=$AD_DIR?>/images/9.jpg"></section>
		<section><img src="<?=$AD_DIR?>/images/10.jpg"></section>
		<section id="inDB">
			<h3>전문상담사가 친절히 상담해 드립니다.</h3>
			<table>
				<colgroup>
					<col width="">
					<col width="">
				</colgroup>
				<tbody>
					<tr>
						<th>성 함</th>
						<td><input type="text" class="form-class"  id="M_NAME2"></td>
					</tr>
					<tr>
						<th>나 이</th>
						<td><input type="number" class="form-class"  id="M_AGE2" style="width:auto; float:left;"> <label style="position:relative;float:left; top:10px; left:10px;">세</label></td>
					</tr>
					<tr>
						<th>연락처</th>
						<td><input type="tel" class="form-class"  id="M_HP2"></td>
					</tr>
					<tr>
						<th>남기고<br>싶은말</th>
						<td>
							<textarea class="form-class" rows="5" id="M_QUESTION2"></textarea>
						</td>
					</tr>
					<tr>
						<td colspan="2" class="t-center">
							<div class="checkbox">
								<input type="checkbox" name="" id="agree2" checked> <label for="agree2">개인정보 수집 및 이용동의</label>
							</div>
						</td>
					</tr>
					<tr>
						<td colspan="2" class="t-center" style="padding:0;">
							<a onclick="APPLY_SUBMIT2();"><img src="<?=$AD_DIR?>/images/btn.jpg"></a>
						</td>
					</tr>
				</tbody>
			</table>
		</section>
		<section><img src="<?=$AD_DIR?>/images/11.jpg"></section>
		<section><img src="<?=$AD_DIR?>/images/12.jpg"></section>
	</div>

<script type="text/javascript">
		var CODE_NAME  = "<?=$CODE_NAME?>";
		var MEDIA_CODE = "<?=$MEDIA_CODE?>";
		var USER_AGENT = "<?=$_SERVER['HTTP_USER_AGENT']?>";
		var REFERER_CODE_NAME  = "<?=$REFERER_CODE_NAME?>";
		var REFERER_MEDIA_CODE = "<?=$REFERER_MEDIA_CODE?>";
	
	var APPLY_SUBMIT = function () {
		
		if ( $("#agree").is(':checked') == false ) {
			alert("개인정보 수집 및 이용동의하셔야 상담을 신청하실수 있습니다.");
			return false;			
		}
		var M_HP     = $("[id=M_HP]").val();
		var M_NAME   = $("[id=M_NAME]").val();
		var M_AGE    = $("[id=M_AGE]").val();
		var M_QUESTION = $("[id=M_QUESTION]").val();
		
		if ( M_NAME == "" ) { alert( "이름을  입력해주십시요."); $("[id=M_NAME]").focus(); return false; }
		if ( M_AGE == "" ) { alert( "나이를 입력해주십시요."); $("[id=M_AGE]").focus(); return false; }
		if ( M_HP == "" ) { alert( "전화번호를 입력해주십시요."); $("[id=M_HP]").focus();return false; }
		if ( M_QUESTION == "" ) { alert( "문의사항을 입력해주십시요."); $("[id=M_QUESTION]").focus();  return false; }

		$.post('/include/process/INSERT_DATA.php',  { CODE_NAME:CODE_NAME , USER_AGENT:USER_AGENT , MEDIA_CODE:MEDIA_CODE , 
													  M_HP:M_HP , M_NAME:M_NAME , M_AGE:M_AGE , M_QUESTION:M_QUESTION , 
													  XFOR:"<?=$_SERVER['HTTP_X_FORWARDED_FOR']?>" , 
													  REFERER_CODE_NAME:REFERER_CODE_NAME , REFERER_MEDIA_CODE:REFERER_MEDIA_CODE
		}, function(data){
		alert("신청 되었습니다.");		
		$("#M_HP").val("");
		$("#M_NAME").val("");
		$("#M_AGE").val("");	
		$("#M_QUESTION").val("");
				
		return true;
		})
	}

	var APPLY_SUBMIT2 = function () {
		
		if ( $("#agree2").is(':checked') == false ) {
			alert("개인정보 수집 및 이용동의하셔야 상담을 신청하실수 있습니다.");
			return false;			
		}
		var M_HP     = $("[id=M_HP2]").val();
		var M_NAME   = $("[id=M_NAME2]").val();
		var M_AGE    = $("[id=M_AGE2]").val();
		var M_QUESTION = $("[id=M_QUESTION2]").val();
		
		if ( M_NAME == "" ) { alert( "이름을  입력해주십시요."); $("[id=M_NAME2]").focus(); return false; }
		if ( M_AGE == "" ) { alert( "나이를 입력해주십시요."); $("[id=M_AGE2]").focus(); return false; }
		if ( M_HP == "" ) { alert( "전화번호를 입력해주십시요."); $("[id=M_HP2]").focus();return false; }
		if ( M_QUESTION == "" ) { alert( "문의사항을 입력해주십시요."); $("[id=M_QUESTION2]").focus();  return false; }

		$.post('/include/process/INSERT_DATA.php',  { CODE_NAME:CODE_NAME , USER_AGENT:USER_AGENT , MEDIA_CODE:MEDIA_CODE , 
													  M_HP:M_HP , M_NAME:M_NAME , M_AGE:M_AGE , M_QUESTION:M_QUESTION , 
													  XFOR:"<?=$_SERVER['HTTP_X_FORWARDED_FOR']?>" , 
													  REFERER_CODE_NAME:REFERER_CODE_NAME , REFERER_MEDIA_CODE:REFERER_MEDIA_CODE
		}, function(data){
		alert("신청 되었습니다.");		
		$("#M_HP2").val("");
		$("#M_NAME2").val("");
		$("#M_AGE2").val("");	
		$("#M_QUESTION2").val("");
				
		return true;
		})
	}
</script>

</body>
</html>